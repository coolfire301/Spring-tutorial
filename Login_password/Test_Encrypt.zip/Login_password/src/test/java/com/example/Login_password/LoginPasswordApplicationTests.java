package com.example.Login_password;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginPasswordApplicationTests {

	@Test
	void contextLoads() {
	}

}
